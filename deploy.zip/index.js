const AWS = require('aws-sdk')

exports.handler = function(event, context, callback) {
  const lambda = new AWS.Lambda({
    'apiVersion': '2015-03-31',
    'region' : 'ap-northeast-1',
    'invocation-type' : 'RequestResponse'
  })

  const params = {
    FunctionName: 'zs-lambda-dev-v2',
    InvocationType: 'RequestResponse',
    LogType: 'Tail',
    Payload: '{"key1":"value1", "key2":"value2", "key3":"value3"}'
  }

  lambda.invoke(params, (err, data) => {
    if (err) callback(`
        Error :
          ${err}
      `, null)
    else callback(`
        Success :
          StatusCode : ${data.StatusCode}
          Payload : ${data.Payload}
      `, null)
  })
}
